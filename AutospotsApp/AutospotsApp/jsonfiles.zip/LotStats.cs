using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Java.Util;

namespace AutospotsApp
{
    class LotStats
    {
        //average open capacity, average open capacity different times of day
        public int lotID { get; set; }
        public float capacity { get; set; }
        public Date time { get; set; } //Only use timestamp, day of month will be ignored
    }
}